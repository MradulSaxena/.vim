## desertink.vim

This is a version of the default desert colorscheme with a darker background and more colorful foreground colors.

A theme for [vim-airline](https://github.com/bling/vim-airline) is included as well.

##### Screenshot (running in tmux and ROXTerm):

![desertink](http://i.imgur.com/MhZ2UFD.png)

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/toupeira/vim-desertink/trend.png)](https://bitdeli.com/free "Bitdeli Badge")
